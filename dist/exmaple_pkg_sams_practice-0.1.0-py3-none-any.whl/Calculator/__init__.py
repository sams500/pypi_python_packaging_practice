""" A simple python package """

__version__ = "0.1.0"
__author__ = 'Soilihi Abderemane'
__author_email__ = 'abdermane500@gmail.com'
