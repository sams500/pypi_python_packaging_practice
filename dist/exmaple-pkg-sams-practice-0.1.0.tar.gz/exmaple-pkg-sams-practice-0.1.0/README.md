# pypi_python_packaging_practice
A simple example of packaging python project

This project will by published in PyPI so that we can use pip install to install and call the function in our loal machine. 
It is the same way, python libraries are published such as numpy, pandas, etc.  

# Tutorial
[Python Packaging Tutorial](https://packaging.python.org/tutorials/packaging-projects/)

## Final Python Package on testPyPI
[Package](https://test.pypi.org/project/exmaple-pkg-sams-practice/0.1.0/)

## More about Markdown
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)

